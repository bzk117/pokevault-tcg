POKEVAULT — VERSION BOUTIQUE PRO
================================
Ouvrir index.html dans un navigateur.

PERSONNALISATION RAPIDE
- Le nom "PokeVault" se change dans index.html.
- Les produits, prix et liens Vinted/eBay sont dans script.js.
- Les boutons Vinted/eBay utilisent actuellement "#": remplacer par les vraies annonces.
- Les visuels sont des maquettes CSS pour cette V2. On peut ensuite intégrer vos vraies photos.
- Aucun paiement/panier : le site sert uniquement de catalogue et redirige vers Vinted/eBay.

PROCHAINE ÉVOLUTION POSSIBLE
- vraies photos produits
- logo définitif
- fiches produits détaillées
- disponibilité
- tri par prix
- plusieurs liens Vinted/eBay par produit
- hébergement en ligne
