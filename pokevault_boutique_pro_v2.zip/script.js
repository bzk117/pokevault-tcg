const data=[
{name:"Booster Bundle 30e Anniversaire FR",meta:"🇫🇷 Français • 6 boosters • Scellé",price:"59,90 €",tags:["fr","sealed"],style:"frpack",vinted:"#",ebay:"#",featured:true},
{name:"Display Pokémon Japonais",meta:"🇯🇵 Japonais • Display • Scellé",price:"89,90 €",tags:["jp","sealed"],style:"jppack",vinted:"#",ebay:"#",featured:true},
{name:"ETB Pokémon Français",meta:"🇫🇷 Français • Elite Trainer Box",price:"69,90 €",tags:["fr","sealed"],style:"bluepack",vinted:"#",ebay:"#",featured:true},
{name:"Carte Pokémon — Rare",meta:"🇫🇷 Français • Carte à l'unité",price:"24,90 €",tags:["fr","card"],style:"cardpack",vinted:"#",ebay:"#",featured:true},
{name:"Bundle Pokémon Japonais",meta:"🇯🇵 Japonais • Produit scellé",price:"39,90 €",tags:["jp","sealed"],style:"jppack",vinted:"#",ebay:"#"},
{name:"Display Japonais — Série récente",meta:"🇯🇵 Japonais • Display • Scellé",price:"119,90 €",tags:["jp","sealed"],style:"bluepack",vinted:"#",ebay:"#"},
{name:"Carte Pokémon — Ultra Rare",meta:"🇫🇷 Français • Carte à l'unité",price:"34,90 €",tags:["fr","card"],style:"cardpack",vinted:"#",ebay:"#"},
{name:"Coffret Pokémon FR",meta:"🇫🇷 Français • Coffret • Scellé",price:"44,90 €",tags:["fr","sealed"],style:"frpack",vinted:"#",ebay:"#"}
];
function card(p){return `<article class="product"><div class="visual"><span class="badge">${p.tags.includes("jp")?"JAPONAIS":"FRANÇAIS"}</span><button class="heart">♡</button><div class="pack ${p.style}">★</div></div><div class="pbody"><h3>${p.name}</h3><div class="meta">${p.meta}</div><div class="bottom"><span class="price">${p.price}</span><div class="links"><a class="vinted" href="${p.vinted}" target="_blank">Vinted</a><a class="ebay" href="${p.ebay}" target="_blank">eBay</a></div></div></div></article>`}
function render(list,id){document.getElementById(id).innerHTML=list.map(card).join("")}
render(data.filter(x=>x.featured),"featured");render(data,"products");
let filter="all";
function apply(){const q=document.getElementById("search").value.toLowerCase();let list=data.filter(p=>(filter==="all"||p.tags.includes(filter))&&(p.name+" "+p.meta).toLowerCase().includes(q));render(list,"products");document.getElementById("result").textContent=list.length+" produit"+(list.length>1?"s":"")}
document.querySelectorAll(".filters button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");filter=b.dataset.f;apply()});
document.getElementById("search").oninput=apply;apply();
const modal=document.getElementById("modal");document.getElementById("searchBtn").onclick=()=>{modal.classList.add("open");document.getElementById("modalSearch").focus()};document.getElementById("close").onclick=()=>modal.classList.remove("open");modal.onclick=e=>{if(e.target===modal)modal.classList.remove("open")};
document.getElementById("modalSearch").oninput=e=>{document.getElementById("search").value=e.target.value;modal.classList.remove("open");apply();document.getElementById("catalogue").scrollIntoView()};